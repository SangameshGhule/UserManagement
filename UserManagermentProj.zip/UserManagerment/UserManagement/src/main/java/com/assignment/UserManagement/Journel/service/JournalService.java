package com.assignment.UserManagement.Journel.service;

import com.assignment.UserManagement.Journel.entity.Journal;
import com.assignment.UserManagement.Journel.repo.JournalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JournalService {

    @Autowired
    private JournalRepository journalRepository;

    public List<Journal> getAllJournals() {
        return journalRepository.findAll();
    }

}

