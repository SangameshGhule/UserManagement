package com.assignment.UserManagement.User.controller;

import com.assignment.UserManagement.User.entity.User;
import com.assignment.UserManagement.User.service.UserService;
import com.assignment.UserManagement.kafka.UserEvent;
import com.assignment.UserManagement.kafka.UserEventProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class UserController {

    private final UserService userService;
    private final UserEventProducer userEventProducer;

    @Autowired
    public UserController(UserService userService, UserEventProducer userEventProducer) {
        this.userService = userService;
        this.userEventProducer = userEventProducer;
    }

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        User registeredUser = userService.registerUser(user);

        UserEvent userEvent = new UserEvent();
        userEvent.setUserId(user.getId());
        userEvent.setEmail(user.getEmail());
        userEvent.setEventType(user.getRoles().toString() + " "+ "Register successfully...");
        userEvent.setEventTimestamp(LocalDateTime.now());

        // Publish event
        userEventProducer.sendUserEvent(userEvent);
        return ResponseEntity.ok(registeredUser);
    }

    @GetMapping("/user/email/{email}")
    public ResponseEntity<User> getUserByEmail(@PathVariable String email) {
        Optional<User> userByEmail = userService.getUserByEmail(email);

        UserEvent userEvent = new UserEvent();
        if(userByEmail.isPresent()) {
            userEvent.setUserId(userByEmail.get().getId());
            userEvent.setEmail(userByEmail.get().getEmail());
            userEvent.setEventType(userByEmail.get().getRoles().toString() + " " + "Get by mail user info fetched successfully...");
            userEvent.setEventTimestamp(LocalDateTime.now());
        }

        // Publish event
        userEventProducer.sendUserEvent(userEvent);

        return userByEmail.map(ResponseEntity::ok)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @GetMapping("/user/id/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Integer id) {
        return userService.getUserById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/user/getAll")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @PutMapping("/user/update/{email}")
    public ResponseEntity<User> updateUser(@PathVariable String email, @RequestBody User user) {
        User updatedUser = userService.updateUser(email, user);

        UserEvent userEvent = new UserEvent();
        if(updatedUser!=null) {
            userEvent.setUserId(updatedUser.getId());
            userEvent.setEmail(updatedUser.getEmail());
            userEvent.setEventType(updatedUser.getRoles().toString() + " " + "Update user info successfully...");
            userEvent.setEventTimestamp(LocalDateTime.now());
        }
        // Publish event
        userEventProducer.sendUserEvent(userEvent);
        return ResponseEntity.ok(updatedUser);
    }

    @DeleteMapping("/user/id/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Integer id) {

        ResponseEntity<User> userResponseEntity = userService.getUserById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
        User user = userResponseEntity.getBody();

        UserEvent userEvent = new UserEvent();
        if(user!=null) {
            userEvent.setUserId(user.getId());
            userEvent.setEmail(user.getEmail());
            userEvent.setEventType(user.getRoles().toString() + " " + "User info delted successfully...");
            userEvent.setEventTimestamp(LocalDateTime.now());
        }
        // Publish event
        userEventProducer.sendUserEvent(userEvent);

        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
}
