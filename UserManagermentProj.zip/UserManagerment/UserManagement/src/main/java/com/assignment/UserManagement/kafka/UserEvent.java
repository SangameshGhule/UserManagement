package com.assignment.UserManagement.kafka;

import ch.qos.logback.core.model.INamedModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserEvent {

    private String eventType;
    private Integer userId;
    private String email;
    private LocalDateTime eventTimestamp;

}
