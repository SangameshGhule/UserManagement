package com.assignment.UserManagement.kafka;

import com.assignment.UserManagement.Journel.entity.Journal;
import com.assignment.UserManagement.Journel.repo.JournalRepository;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class UserEventConsumer {

    private final JournalRepository journalRepository;

    public UserEventConsumer(JournalRepository journalRepository) {
        this.journalRepository = journalRepository;
    }

    @KafkaListener(topics = "${spring.kafka.topic.name}", groupId = "${spring.kafka.consumer.group-id}")
    public void consume(UserEvent userEvent) {
        System.out.println("Event received: " + userEvent);
        try {
            Journal journal = new Journal();
            journal.setEventMessage(userEvent.toString());
            journal.setTimestamp(userEvent.getEventTimestamp());
            journalRepository.save(journal);
            System.out.println("Event saved to the journal: " + userEvent);
        } catch (Exception e) {
            System.err.println("Error processing event: " + e.getMessage());
        }
    }
}
