package com.assignment.UserManagement.User.controller;

import com.assignment.UserManagement.User.entity.User;
import com.assignment.UserManagement.User.service.UserService;
import com.assignment.UserManagement.kafka.UserEventProducer;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;


import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(controllers = UserController.class)
@Import(SecurityConfigTest.class)
@AutoConfigureMockMvc
public class UserControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @MockBean
    private UserEventProducer userEventProducer;

    @Test
    @WithMockUser(username = "sangamesh", roles = {"ADMIN"})
    void registerUser() throws Exception {
        User user = new User();
        user.setId(1);
        user.setName("sangamesh");
        user.setEmail("sangamesh@gmail.com");
        user.setRoles(List.of("ROLE_ADMIN"));

        when(userService.registerUser(any(User.class))).thenReturn(user);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/api/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\n" +
                        "  \"name\": \"sangamesh\",\n" +
                        "  \"email\": \"sangamesh@gmail.com\",\n" +
                        "  \"password\": \"password123\",\n" +
                        "  \"roles\": [\"ROLE_ADMIN\"]\n" +
                        "}");
        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk()) // Ensure that the response status is OK
                .andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
        assertNotNull(response.getContentAsString());
    }


    @Test
    void UserFound() throws Exception {
        // Arrange
        Integer userId = 1;
        User user = new User();
        user.setId(userId);
        user.setName("sangamesh");
        user.setEmail("sangamesh@example.com");
        user.setRoles(List.of("ROLE_USER"));
        when(userService.getUserById(userId)).thenReturn(Optional.of(user));
        assertEquals("sangamesh@example.com",user.getUsername());
    }

    @Test
    void UserNotFound() throws Exception {
        Integer userId = 1;
        when(userService.getUserById(userId)).thenReturn(Optional.empty());
        mockMvc.perform(MockMvcRequestBuilders.get("/api/user/{id}", userId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound()); // Verify that the status is 404 Not Found
    }
}
